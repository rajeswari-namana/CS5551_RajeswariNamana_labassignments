/**
 * Created by rajin on 10/4/2017.
 */
export const environment: any = {
  production: true,
};
