/**
 * Created by rajin on 10/12/2017.
 */
/**
 * Created by Marmik on 04/10/2016.
 */
var express = require('express');
var app = express();
var request = require('request');
app.get('/getTheatres', function (req, res) {
    var result={
        'theatres': [],
        'analysis' : []
    };

    request('https://maps.googleapis.com/maps/api/place/search/json?location=-33.8670522,151.1957362&radius=300000&type=movie_theater&sensor=true&key=AIzaSyCXpd1MNs44B5NJ5xs2PsTDeGFjlXC8ORw', function (error, response, body) {
        //Check for error
        if(error){
            return console.log('Error:', error);
        }

        //Check for right status code
        if(response.statusCode !== 200){
            return console.log('Invalid Status Code Returned:', response.statusCode);
        }
        //All is good. Print the body
        body = JSON.parse(body);
        var ven = body.results;

console.log(ven);
      for(var i=0;i<ven.length;i++)
     {
      result.theatres.push({'name': ven[i].name,'rating': ven[i].rating, 'place_id': ven[i].place_id, 'vicinity': ven[i].vicinity, 'types': ven[i].types });
       }
result.analysis.push({"negative":0.364668,"positive":0.635332});
        res.contentType('application/json');
        res.write(JSON.stringify(result));
        res.end();
    });
    console.log(result);


});


request('https://api.uclassify.com/v1/uclassify/sentiment/classify?readkey=H2NmEMjuRiLt&text=3.5', function (error, response, body) {
  //Check for error
  if(error){
    return console.log('Error:', error);
  }

  //Check for right status code
  if(response.statusCode !== 200){
    return console.log('Invalid Status Code Returned:', response.statusCode);
  }
  //All is good. Print the body
  body = JSON.parse(body);
  var ven = body.results;

  console.log(ven);
   result.analysis.push({"negative":0.364668,"positive":0.635332});
  res.contentType('application/json');
  res.write(JSON.stringify(result));
  res.end();
});



});




var server = app.listen(8081, "127.0.0.1", function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log("Example app listening at http://%s:%s", host, port)
});
